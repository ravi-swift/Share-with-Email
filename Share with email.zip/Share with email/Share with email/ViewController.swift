//
//  ViewController.swift
//  Share with email
//
//  Created by Rp on 12/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func clickOnMail(){
       
        if MFMailComposeViewController.canSendMail(){

        
        let controller = MFMailComposeViewController()
       controller.delegate = self
        controller.setSubject("yuyuy")
        controller.setMessageBody("yuyuyuy", isHTML: true)
        controller.setToRecipients(["dharmesh@gmail.com"])
        
        self.present(controller, animated: true, completion: nil)
            
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        switch result {
        case .sent:
            break
            
        case .cancelled:
            break
            
        case .failed:
            break
            
        }
    }
    
    @IBAction func clickOnMessage(){
        
        if MFMessageComposeViewController.canSendText(){
            
        let messanger = MFMessageComposeViewController.init()
        
        messanger.body = "Abc"
        messanger.subject = "AAAA"
        messanger.recipients = ["8000797777"]
        
        self.present(messanger, animated: true, completion: nil)
        
    }
        
    }
    
    @IBAction func clickOnCall(){
        
        if let url = URL(string: "tel://8000797777"),UIApplication.shared.canOpenURL(url){
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

